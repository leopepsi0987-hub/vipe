export default {
  plugins: {
    "postcss-import": {},
    "postcss-nesting": {},
    "tailwindcss": {},
    "autoprefixer": {},
  },
};
