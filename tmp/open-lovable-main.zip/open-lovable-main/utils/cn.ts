import classNames from "classnames";

export function cn(...classes: classNames.ArgumentArray) {
  return classNames(...classes);
}
