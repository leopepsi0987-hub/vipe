import { atom } from 'jotai';

export const isMobileSheetOpenAtom = atom(false);